package com.example.arch.firstproject;


import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.arch.firstproject.Common.Common;
import com.example.arch.firstproject.Helper.Helper;
import com.example.arch.firstproject.Model.openWeather;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Picasso;

import java.lang.reflect.Type;

import static android.webkit.ConsoleMessage.MessageLevel.LOG;

public class MainActivity extends AppCompatActivity implements LocationListener {

    TextView txtCity, txtLastUpdate, txtDescription, txtHumidity, txtTime, txtCelsius;
    ImageView imageview;
    LocationManager locationmanager;
    String provider;
    static double lat, lng;

    openWeather openweather = new openWeather();

    int MY_PERMISSION = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //CONTROL1
        txtCity = (TextView)findViewById(R.id.txtCity);
        txtLastUpdate = (TextView)findViewById(R.id.txtLastUpdate);
        txtDescription = (TextView)findViewById(R.id.txtDescription);
        txtHumidity = (TextView)findViewById(R.id.txtHumidity);
        txtTime = (TextView)findViewById(R.id.txtTime);
        txtCelsius = (TextView)findViewById(R.id.txtCelsius);
        imageview = (ImageView)findViewById(R.id.imageview);

        //Get cooridinates
        locationmanager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        provider = locationmanager.getBestProvider(new Criteria(), false);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                    Manifest.permission.INTERNET,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_NETWORK_STATE,
                    Manifest.permission.SYSTEM_ALERT_WINDOW,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,


            }, MY_PERMISSION);


        }
        Location location = locationmanager.getLastKnownLocation(provider);
        if (location == null) {
            Log.e("TAG","NO LOCATION");
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        locationmanager.removeUpdates(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                    Manifest.permission.INTERNET,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_NETWORK_STATE,
                    Manifest.permission.SYSTEM_ALERT_WINDOW,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,


            }, MY_PERMISSION);

        }
        locationmanager.requestLocationUpdates(provider, 400, 1, this);
    }

    @Override
    public void onLocationChanged(Location location) {
        lat= location.getLatitude();
        lng = location.getLongitude();

        new GetWeather().execute(Common.apiRequest(String.valueOf(lat),String.valueOf(lng)));

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    private class GetWeather extends AsyncTask<String,Void,String> {
        ProgressDialog pd = new ProgressDialog(MainActivity.this);


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd.setTitle("Please wait.....");
          
            pd.show();
        }


        @Override
        protected String doInBackground(String... paramas) {
            String stream = null;
            String urlString = paramas[0];

            Helper http=new Helper();
            stream = http.getHTTData(urlString);
            return stream;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s.contains ("Error not found city")){
                pd.dismiss();
                return ;
            }
            Gson gson = new Gson();
            Type mType = new TypeToken<openWeather>() {}.getType();
            openweather = gson.fromJson(s,mType);
            pd.dismiss();

            txtCity.setText(String.format("%S,%s",openweather.getName(),openweather.getSys().getCountry()));
            txtLastUpdate.setText(String.format("Last Updat:%s", Common.getDateNow()));
            txtDescription.setText(String.format("%s",openweather.getWeather().get(0).getDescription()));
            txtHumidity.setText(String.format("%d%%",openweather.getMain().getHumidity()));
            txtTime.setText(String.format("%s/%s",Common.unixTimeStampToDateTime(openweather.getSys().getSunrise()),Common.unixTimeStampToDateTime(openweather.getSys().getSunrest())));
            txtCelsius.setText(String.format("%.2f °C",openweather.getMain().getTemp()));
            Picasso.get()
                    .load(Common.getImage(openweather.getWeather().get(0).getIcon()))
                    .into(imageview);




        }
    }
}
