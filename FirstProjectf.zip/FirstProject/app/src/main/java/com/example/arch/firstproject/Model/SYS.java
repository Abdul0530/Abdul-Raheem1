package com.example.arch.firstproject.Model;

public class SYS {
    private int id;
    private double massage;
    private String country;
    private double sunrise;
    private double sunrest;

    public SYS(int id, double massage, String country, double sunrise, double sunrest) {
        this.id = id;
        this.massage = massage;
        this.country = country;
        this.sunrise = sunrise;
        this.sunrest = sunrest;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getMassage() {
        return massage;
    }

    public void setMassage(double massage) {
        this.massage = massage;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public double getSunrise() {
        return sunrise;
    }

    public void setSunrise(double sunrise) {
        this.sunrise = sunrise;
    }

    public double getSunrest() {
        return sunrest;
    }

    public void setSunrest(double sunrest) {
        this.sunrest = sunrest;
    }
}
